package inhereants;

import javax.swing.JOptionPane;

public class People {

	protected String name;
	protected String surName;
	protected String gender;
	protected String age;
	protected int tel=4555555;
	
	protected void display() {
		JOptionPane.showMessageDialog(null, "This is Super Class");
	}
}
