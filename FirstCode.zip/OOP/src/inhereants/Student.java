package inhereants;

import javax.swing.JOptionPane;

public class Student extends People {

	private int id;
	
	public void setId(int number) {
		id=number;
	}
	public void display() {
		super.display();
		
		JOptionPane.showMessageDialog(null,
				"Name "+name+"\n"+"Sur Name "+surName+"\n"+
		"Gender "+gender+"\n"+"Age "+age+"\n"+"Tel "+super.tel);
		
	}
}
