package inhereants;

public class MainApp {

	public static void main(String[] args) {
		Student stu=new Student();

		stu.name="Tarza";
		stu.surName="Jalal";
		stu.age="19";
		stu.gender="Female";
		stu.setId(12);
		
		stu.display();
	}

}
